# Mertcan Köse

# Akakçe Ürün Detay Sayfası

Bu proje, Akakçe websitesindeki bir ürünün detaylarını içeren bir HTML ve CSS dosyasını içermektedir.

## Açıklama

Bu HTML ve CSS dosyası, Akakçe websitesindeki bir ürünün detaylarını gösteren bir sayfayı temsil etmektedir. Sayfa, ürünün başlığı, görselleri, fiyat teklifleri, özellikleri ve daha fazlasını içermektedir.

## Kurulum

Projeyi bilgisayarınıza indirin ve index.html dosyasını açın.
